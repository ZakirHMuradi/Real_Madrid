name = input("Enter your name: ")
print("your name is ", Aizada)

age = input("Enter your name: ")
print("your name is ", 18-19)

surname = input("Enter your name: ")
print("your name is ", berdibekova)

speciality = input("Enter your name: ")
print("your name is ", Computer Science)

country = input("Enter your name: ")
print("your name is ", Kyrgyzstan)

email = input("Enter your name: ")
print("your name is ", aizada.berdibecova@gmail.com)

gender= input("Enter your name: ")
print("your name is ", female)

birthday = input("Enter your name: ")
print("your name is ",27/07/2003)

cohort = input("Enter your name: ")
print("your name is ", cohort1 - Science cohort)

name = input("Enter your name: ")
print("your name is ", Aizada)

age = input("Enter your name: ")
print("your name is ", 18)

surname = input("Enter your name: ")
print("your name is ", Berdibekova)

cohort = input("Enter your name: ")
print("your name is ", cohort)

birthday = input("Enter your name: ")
print("your name is ",18)

gender= input("Enter your name: ")
print("your name is ", feamle)

email = input("Enter your name: ")
print("your name is ", aizada.berdiebcova@gmail.com)

country = input("Enter your name: ")
print("your name is ", Kyrgyzsatn)

speciality = input("Enter your name: ")
print("your name is ", IT, CS)
